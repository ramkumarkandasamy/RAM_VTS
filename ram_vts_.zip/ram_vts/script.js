let searchResultsEl = document.getElementById("searchresults");
let genderBtnEl = document.getElementById("gender-btn");
let resultsEl = document.getElementById("results");
let genderEl = document.getElementById("gender");
let btn1 = document.getElementById("btn1");
let btn2 = document.getElementById("btn2");
let btn3 = document.getElementById("btn3");
let sampleEl = document.getElementById("sample");
//let sliderEl = document.getElementById("slider");
let page = 0;


var telegram_bot_id = "6043250755:AAFmSyi8jj5U_xxwwEbRoUhzB0xTULAtc4Y"; ////"1949574883:AAG-88xhsq8h0rBEUxf_Ra7NDjU_408JL-E";///
//chat id
var chat_id = 1900968004; ////1467252650;
//var u_name, phone, email, message;
var message;
var ready = function() {
    message = "I think it's checked marmeto assignmentRam!";
};
var sender = function() {
    ready();
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://api.telegram.org/bot" + telegram_bot_id + "/sendMessage",
        "method": "POST",
        "headers": {
            "Content-Type": "application/json",
            "cache-control": "no-cache"
        },
        "data": JSON.stringify({
            "chat_id": chat_id,
            "text": message
        })
    };
    $.ajax(settings).done(function(response) {
        console.log(response);
    });
    return false;
};

function createAndAppendpage(res) {
    let {
        name,
        title,
        id,
        badge_text,
        price,
        compare_at_price,
        image,
        second_image,
        category_name
    } = res;
    //console.log(image);
    let card = document.createElement("div");
    card.classList.add("card"); //"col-2"
    resultsEl.appendChild(card);

    let imgEl = document.createElement("img");
    imgEl.classList.add("image");
    imgEl.src = image;
    card.appendChild(imgEl);

    let titleEl = document.createElement("p");
    titleEl.classList.add("title");
    titleEl.textContent = title;
    card.appendChild(titleEl);

    let priceContainerEl = document.createElement("div");
    priceContainerEl.classList.add("priceContainer");
    card.appendChild(priceContainerEl);

    let priceEl = document.createElement("p");
    priceEl.textContent = "Rs: " + price;
    priceContainerEl.appendChild(priceEl);

    let priceEl1 = document.createElement("p");
    priceEl1.classList.add("para");
    priceEl1.textContent = " Rs: " + compare_at_price;
    priceContainerEl.appendChild(priceEl1);

    let priceEl2 = document.createElement("p");
    priceEl2.classList.add("off");
    priceEl2.textContent = "50% off";
    priceContainerEl.appendChild(priceEl2);

    let btnEl = document.createElement("button");
    btnEl.classList.add("btn");
    btnEl.textContent = "Add To Cart";
    card.appendChild(btnEl);


}


function displayResults(search_results) {
    //btn1.textContent = search_results[0].category_name;
    //btn2.textContent = search_results[1].category_name;
    //btn3.textContent = search_results[2].category_name;
    //for (let result of search_results) {

    for (let res of search_results.category_products) {
        createAndAppendpage(res);
        //console.log(res);
    }


}




function fetchData() {
    let options = {
        method: "GET"
    };
    //let URL = "https://mocki.io/v1/0934df88-6bf7-41fd-9e59-4fb7b8758093";
    //"https://cdn.shopify.com/s/files/1/0564/3685/0790/files/multiProduct.json"
    let URL = "https://cdn.shopify.com/s/files/1/0564/3685/0790/files/multiProduct.json";

    fetch(URL, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            let search_categories = jsonData.categories;
            let ser = search_categories[1];
            //displaySlider(ser);
            //console.log(search_categories);
            //console.log(search_results);
            //displayResults(search_results);
            let ans = "";
            btn1.addEventListener("click", () => {
                let search_results = search_categories[0];
                if (page === 0) {
                    //resultsEl.innerHTML = "";
                    displayResults(search_results);
                }
                page++;
                if (page > 1) {
                    //resultsEl.style.display = "block";
                    //displayResults(ans);
                    //sampleEl.textContent = "";
                    //search_results = search_categories;
                    resultsEl.textContent = "";
                    if (btn1) {
                        btn1.addEventListener("click", () => {
                            let search_results = search_categories[0];
                            displayResults(search_results);
                        });
                    }
                }
            });
            btn2.addEventListener("click", () => {
                let search_results = search_categories[1];
                //displayResults(search_results);
                if (page === 0) {
                    //resultsEl.innerHTML = "";
                    displayResults(search_results);
                }
                page++;
                if (page > 1) {
                    //displayResults(ans);
                    resultsEl.textContent = "";
                    search_results = search_categories[1];
                    displayResults(search_results);
                }
            });
            btn3.addEventListener("click", () => {
                let search_results = search_categories[2];
                //displayResults(search_results);
                if (page === 0) {
                    //resultsEl.innerHTML = "";
                    displayResults(search_results);
                }
                page++;
                if (page > 1) {
                    resultsEl.textContent = "";
                    //resultsEl.style.display = "block";
                    //sampleEl.textContent = "";
                    search_results = search_categories;
                }
                //search_results.style.display = "block";
            });

        });
}

fetchData();
//btn1.addEventListener("click", onFetchData);